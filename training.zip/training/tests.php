<?php include 'config.php'; 

if (!isLoggedIn()) {
    redirect('login.php');
}

$tests = $pdo->query("SELECT t.*, u.username as created_by_username FROM tests t JOIN users u ON t.created_by = u.id ORDER BY t.created_at DESC")->fetchAll();

$passed_tests = [];
if (!isAdmin()) {
    $stmt = $pdo->prepare("SELECT test_id FROM test_results WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $passed_tests = $stmt->fetchAll(PDO::FETCH_COLUMN);
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Доступные тесты</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .test-card {
            transition: transform 0.3s;
            height: 100%;
        }
        .test-card:hover {
            transform: translateY(-5px);
        }
        .badge-new {
            background-color: #20c997;
        }
    </style>
</head>
<body>
    <!-- Навигация -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Обучение персонала</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo isAdmin() ? 'admin.php' : 'dashboard.php'; ?>">
                            <?php echo isAdmin() ? 'Админ-панель' : 'Личный кабинет'; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="tests.php">Тесты</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link"><?php echo isAdmin() ? 'Администратор' : 'Пользователь'; ?>: <?php echo $_SESSION['username']; ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Выйти</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <h2 class="mb-4">Доступные тесты</h2>
        
        <?php if (empty($tests)): ?>
            <div class="alert alert-info">
                На данный момент нет доступных тестов.
                <?php if (isAdmin()): ?>
                    <a href="add_test.php" class="alert-link">Добавить тест</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php foreach ($tests as $test): ?>
                    <div class="col">
                        <div class="card test-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h5 class="card-title mb-0"><?php echo htmlspecialchars($test['title']); ?></h5>
                                </div>
                                <p class="card-text text-muted small">Создал: <?php echo htmlspecialchars($test['created_by_username']); ?></p>
                                <p class="card-text"><?php echo htmlspecialchars($test['description']); ?></p>
                            </div>
                            <div class="card-footer bg-transparent">
                                <?php if (isAdmin()): ?>
                                    <div class="d-flex justify-content-between">
                                        <a href="edit_test.php?id=<?php echo $test['id']; ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-pencil"></i> Редактировать
                                        </a>
                                        <a href="delete_test.php?id=<?php echo $test['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Вы уверены? Все вопросы и результаты этого теста будут удалены.');">
                                            <i class="bi bi-trash"></i> Удалить
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <a href="take_test.php?id=<?php echo $test['id']; ?>" class="btn btn-primary w-100">
                                        <?php echo in_array($test['id'], $passed_tests) ? 'Пройти снова' : 'Пройти тест'; ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>