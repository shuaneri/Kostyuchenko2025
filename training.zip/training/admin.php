<?php include 'config.php'; 

if (!isLoggedIn() || !isAdmin()) {
    redirect('login.php');
}

$tests = $pdo->query("SELECT t.*, u.username as created_by_username FROM tests t JOIN users u ON t.created_by = u.id ORDER BY t.created_at DESC")->fetchAll();

$users = $pdo->query("SELECT * FROM users ORDER BY role DESC, created_at DESC")->fetchAll();

$test_results = $pdo->query("
    SELECT tr.*, t.title as test_title, u.username, u.full_name 
    FROM test_results tr 
    JOIN tests t ON tr.test_id = t.id 
    JOIN users u ON tr.user_id = u.id 
    ORDER BY tr.completed_at DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ-панель</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .admin-nav .nav-link {
            border-radius: 0;
            padding: 1rem;
            color: #495057;
        }
        .admin-nav .nav-link.active {
            background-color: #f8f9fa;
            color: #0d6efd;
            border-left: 3px solid #0d6efd;
        }
        .admin-nav .nav-link:hover:not(.active) {
            background-color: #f8f9fa;
        }
        .badge-admin {
            background-color: #dc3545;
        }
        .badge-user {
            background-color: #6c757d;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Обучение персонала</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="admin.php">Админ-панель</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">Администратор: <?php echo $_SESSION['username']; ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Выйти</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-3">
        <div class="row">
            <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="admin-nav pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#tests-tab">
                                <i class="bi bi-list-check me-2"></i>Тесты
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#users-tab">
                                <i class="bi bi-people me-2"></i>Пользователи
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#results-tab">
                                <i class="bi bi-clipboard-data me-2"></i>Результаты
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="add_test.php">
                                <i class="bi bi-plus-circle me-2"></i>Добавить тест
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="col-md-9 col-lg-10 ms-sm-auto px-md-4 py-4">
                <?php displayMessage(); ?>
                
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="tests-tab">
                        <h2 class="mb-4">Управление тестами</h2>
                        
                        <div class="card mb-4">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Название</th>
                                                <th>Описание</th>
                                                <th>Создал</th>
                                                <th>Дата создания</th>
                                                <th>Действия</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($tests as $test): ?>
                                                <tr>
                                                    <td><?php echo $test['id']; ?></td>
                                                    <td><?php echo htmlspecialchars($test['title']); ?></td>
                                                    <td><?php echo htmlspecialchars($test['description']); ?></td>
                                                    <td><?php echo htmlspecialchars($test['created_by_username']); ?></td>
                                                    <td><?php echo date('d.m.Y H:i', strtotime($test['created_at'])); ?></td>
                                                    <td>
                                                        <a href="edit_test.php?id=<?php echo $test['id']; ?>" class="btn btn-sm btn-outline-primary me-1">
                                                            <i class="bi bi-pencil"></i>
                                                        </a>
                                                        <form action="delete_test.php" method="POST" style="display: inline;">
                                                            <input type="hidden" name="test_id" value="<?php echo $test['id']; ?>">
                                                            <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Вы уверены? Все вопросы и результаты этого теста будут удалены.');">
                                                                <i class="bi bi-trash"></i>
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        
                        <a href="add_test.php" class="btn btn-primary">
                            <i class="bi bi-plus-circle me-1"></i> Добавить тест
                        </a>
                    </div>
                    
                    <div class="tab-pane fade" id="users-tab">
                        <h2 class="mb-4">Управление пользователями</h2>
                        
                        <div class="card mb-4">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Имя пользователя</th>
                                                <th>Полное имя</th>
                                                <th>Email</th>
                                                <th>Роль</th>
                                                <th>Дата регистрации</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($users as $user): ?>
                                                <tr>
                                                    <td><?php echo $user['id']; ?></td>
                                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                                    <td>
                                                        <span class="badge rounded-pill <?php echo $user['role'] === 'admin' ? 'badge-admin' : 'badge-user'; ?>">
                                                            <?php echo $user['role'] === 'admin' ? 'Админ' : 'Пользователь'; ?>
                                                        </span>
                                                    </td>
                                                    <td><?php echo date('d.m.Y H:i', strtotime($user['created_at'])); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="results-tab">
                        <h2 class="mb-4">Результаты тестирования</h2>
                        
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Пользователь</th>
                                                <th>Тест</th>
                                                <th>Результат</th>
                                                <th>Статус</th>
                                                <th>Дата прохождения</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($test_results as $result): ?>
                                                <tr class="<?php echo $result['passed'] ? '' : 'table-danger'; ?>">
                                                    <td><?php echo $result['id']; ?></td>
                                                    <td><?php echo htmlspecialchars($result['full_name']); ?> (<?php echo htmlspecialchars($result['username']); ?>)</td>
                                                    <td><?php echo htmlspecialchars($result['test_title']); ?></td>
                                                    <td><?php echo $result['score'] . '/' . $result['total_questions']; ?></td>
                                                    <td>
                                                        <?php if ($result['passed']): ?>
                                                            <span class="badge bg-success">Пройден</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-danger">Не пройден</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo date('d.m.Y H:i', strtotime($result['completed_at'])); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>