-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 07 2025 г., 14:29
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `employee_training`
--

-- --------------------------------------------------------

--
-- Структура таблицы `questions`
--

CREATE TABLE `questions` (
  `id` int NOT NULL,
  `test_id` int NOT NULL,
  `question_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `option1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correct_option` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `questions`
--

INSERT INTO `questions` (`id`, `test_id`, `question_text`, `option1`, `option2`, `option3`, `option4`, `correct_option`) VALUES
(1, 1, 'Что означает аббревиатура SQL?', 'Structured Query Language', 'Simple Query Language', 'Standard Query Language', 'Structured Question Language', 1),
(2, 1, 'Какая команда используется для извлечения данных из таблицы?', 'GET', 'SELECT', 'EXTRACT', 'PULL', 2),
(3, 1, 'Какой оператор используется для фильтрации групп в HAVING?', 'WHERE', 'GROUP BY', 'HAVING', 'FILTER', 3),
(4, 1, 'Как создать новую таблицу в SQL?', 'CREATE TABLE', 'NEW TABLE', 'ADD TABLE', 'MAKE TABLE', 1),
(5, 1, 'Какой оператор используется для обновления данных в таблице?', 'MODIFY', 'CHANGE', 'UPDATE', 'ALTER', 3),
(6, 1, 'Какой оператор полностью удаляет таблицу из базы данных?', 'DELETE TABLE', 'REMOVE TABLE', 'DROP TABLE', 'ERASE TABLE', 3),
(7, 1, 'Какой тип JOIN возвращает все строки из обеих таблиц, где есть совпадения?', 'INNER JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'FULL JOIN', 1),
(8, 1, 'Какой оператор используется для сортировки результатов запроса?', 'SORT BY', 'ORDER BY', 'GROUP BY', 'ARRANGE BY', 2),
(9, 1, 'Какой оператор SQL используется для вставки новых данных в таблицу?', 'ADD RECORD', 'INSERT INTO', 'ADD DATA', 'CREATE RECORD', 2),
(10, 1, 'Что делает оператор LIKE в SQL?', 'Сравнивает значения на равенство', 'Проверяет, содержит ли строка определенный шаблон', 'Сравнивает числовые значения', 'Проверяет, является ли значение NULL', 2),
(11, 2, 'С помощью какого тега можно вставить рисунок?', 'img', 'br', 'p', 'table', 1),
(12, 2, 'HTML - это', 'приложение', 'язык программирования', 'язык разметки гипертекста', 'текстовый процессор', 3),
(13, 2, 'Значение атрибута align не может быть', 'left', 'center', 'color', '', 3),
(14, 2, 'Тэги разметки заключаются между знаками…', '/…/', '\\.../', 'не используются', '<…>', 4),
(15, 2, 'Для перехода текста на новую строку используется тэг…', 'html', 'br', 'font', 'body', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `tests`
--

CREATE TABLE `tests` (
  `id` int NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `tests`
--

INSERT INTO `tests` (`id`, `title`, `description`, `created_at`, `created_by`) VALUES
(1, 'Основы SQL', 'Тест по базовым понятиям и командам SQL', '2024-05-06 18:42:02', 1),
(2, 'Проверка основ HTML', 'Тест включает в себя 5 вопросов и позволяет проверить знание основных тегов языка HTML', '2025-05-06 18:51:08', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `test_results`
--

CREATE TABLE `test_results` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `test_id` int NOT NULL,
  `score` int NOT NULL,
  `total_questions` int NOT NULL,
  `passed` tinyint(1) NOT NULL,
  `completed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `test_results`
--

INSERT INTO `test_results` (`id`, `user_id`, `test_id`, `score`, `total_questions`, `passed`, `completed_at`) VALUES
(1, 2, 2, 0, 5, 0, '2025-05-07 04:46:04'),
(2, 2, 2, 0, 5, 0, '2025-05-07 04:47:51'),
(5, 2, 2, 5, 5, 1, '2025-05-07 04:54:17');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `full_name`, `role`, `created_at`) VALUES
(1, 'admin', '$2y$10$ub5LhF7aEQ9O6lM.KodrJ.qKCJlad91XnKm2ViPZXkPQMD1omdBPi', 'admin@admin.com', 'Администратор', 'admin', '2025-05-06 18:24:43'),
(2, 'user', '$2y$10$lJAQg6owcBnQOz85L44rkugBWPWsg04cw.HVQ1XZC3T9kG4S2RgX2', 'okokokok@mail.ru', 'Иван Сорокин', 'user', '2025-05-06 18:28:26');

-- --------------------------------------------------------

--
-- Структура таблицы `user_answers`
--

CREATE TABLE `user_answers` (
  `id` int NOT NULL,
  `test_result_id` int NOT NULL,
  `question_id` int NOT NULL,
  `answer` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `user_answers`
--

INSERT INTO `user_answers` (`id`, `test_result_id`, `question_id`, `answer`) VALUES
(1, 1, 11, 1),
(2, 1, 12, 3),
(3, 1, 13, 3),
(4, 1, 14, 4),
(5, 1, 15, 2),
(6, 2, 11, 1),
(7, 2, 12, 3),
(8, 2, 13, 3),
(9, 2, 14, 4),
(10, 2, 15, 2),
(13, 5, 11, 1),
(14, 5, 12, 3),
(15, 5, 13, 3),
(16, 5, 14, 4),
(17, 5, 15, 2);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `test_id` (`test_id`);

--
-- Индексы таблицы `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Индексы таблицы `test_results`
--
ALTER TABLE `test_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `test_id` (`test_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Индексы таблицы `user_answers`
--
ALTER TABLE `user_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `test_result_id` (`test_result_id`),
  ADD KEY `question_id` (`question_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `tests`
--
ALTER TABLE `tests`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `test_results`
--
ALTER TABLE `test_results`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `user_answers`
--
ALTER TABLE `user_answers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `tests`
--
ALTER TABLE `tests`
  ADD CONSTRAINT `tests_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `test_results`
--
ALTER TABLE `test_results`
  ADD CONSTRAINT `test_results_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `test_results_ibfk_2` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`);

--
-- Ограничения внешнего ключа таблицы `user_answers`
--
ALTER TABLE `user_answers`
  ADD CONSTRAINT `user_answers_ibfk_1` FOREIGN KEY (`test_result_id`) REFERENCES `test_results` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_answers_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
