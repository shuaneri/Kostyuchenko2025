<?php include 'config.php'; 

if (!isLoggedIn() || !isAdmin()) {
    redirect('login.php');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $errors = [];
    if (empty($title)) $errors[] = "Название теста обязательно";
    
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("INSERT INTO tests (title, description, created_by) VALUES (?, ?, ?)");
            $stmt->execute([$title, $description, $_SESSION['user_id']]);
            $test_id = $pdo->lastInsertId();
            
            foreach ($_POST['questions'] as $question) {
                $question_text = trim($question['text']);
                $option1 = trim($question['option1']);
                $option2 = trim($question['option2']);
                $option3 = trim($question['option3']);
                $option4 = trim($question['option4']);
                $correct_option = (int)$question['correct_option'];
                
                if (!empty($question_text) && !empty($option1) && !empty($option2)) {
                    $stmt = $pdo->prepare("INSERT INTO questions (test_id, question_text, option1, option2, option3, option4, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$test_id, $question_text, $option1, $option2, $option3, $option4, $correct_option]);
                }
            }
            
            $pdo->commit();
            
            $_SESSION['message'] = "Тест успешно добавлен!";
            $_SESSION['message_type'] = "success";
            redirect('admin.php');
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Ошибка при добавлении теста: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Добавить тест</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .question-card {
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Обучение персонала</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">Админ-панель</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="add_test.php">Добавить тест</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">Администратор: <?php echo $_SESSION['username']; ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Выйти</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <h2 class="mb-4">Добавить новый тест</h2>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?>
                    <p class="mb-0"><?php echo $error; ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Название теста *</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Описание теста</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                </div>
            </div>
            
            <h4 class="mb-3">Вопросы теста</h4>
            
            <div id="questions-container">
            </div>
            
            <div class="d-flex justify-content-between mb-4">
                <button type="button" id="add-question" class="btn btn-outline-primary">
                    <i class="bi bi-plus-circle"></i> Добавить вопрос
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save"></i> Сохранить тест
                </button>
            </div>
        </form>
    </div>


    <template id="question-template">
        <div class="question-card">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0">Вопрос #<span class="question-number"></span></h5>
                <button type="button" class="btn btn-sm btn-outline-danger remove-question">
                    <i class="bi bi-trash"></i> Удалить
                </button>
            </div>
            <div class="mb-3">
                <label class="form-label">Текст вопроса *</label>
                <input type="text" class="form-control question-text" name="questions[0][text]" required>
            </div>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Вариант 1 *</label>
                    <input type="text" class="form-control" name="questions[0][option1]" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Вариант 2 *</label>
                    <input type="text" class="form-control" name="questions[0][option2]" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Вариант 3</label>
                    <input type="text" class="form-control" name="questions[0][option3]">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Вариант 4</label>
                    <input type="text" class="form-control" name="questions[0][option4]">
                </div>
                <div class="col-12">
                    <label class="form-label">Правильный вариант *</label>
                    <select class="form-select" name="questions[0][correct_option]" required>
                        <option value="1">Вариант 1</option>
                        <option value="2">Вариант 2</option>
                        <option value="3">Вариант 3</option>
                        <option value="4">Вариант 4</option>
                    </select>
                </div>
            </div>
        </div>
    </template>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const questionsContainer = document.getElementById('questions-container');
            const addQuestionBtn = document.getElementById('add-question');
            const questionTemplate = document.getElementById('question-template');
            let questionCount = 0;
            
       
            addQuestion();
            
    
            addQuestionBtn.addEventListener('click', addQuestion);
            
   
            function addQuestion() {
                questionCount++;
                const questionClone = document.importNode(questionTemplate.content, true);
                
                const questionDiv = questionClone.querySelector('.question-card');
                const inputs = questionDiv.querySelectorAll('input, select');
                const questionNumber = questionDiv.querySelector('.question-number');
                
                questionNumber.textContent = questionCount;
                
                inputs.forEach(input => {
                    const name = input.name.replace('questions[0]', `questions[${questionCount}]`);
                    input.name = name;
                });
                
                const removeBtn = questionDiv.querySelector('.remove-question');
                removeBtn.addEventListener('click', function() {
                    if (questionsContainer.children.length > 1) {
                        questionDiv.remove();
                        updateQuestionNumbers();
                    } else {
                        alert('Тест должен содержать хотя бы один вопрос');
                    }
                });
                
                questionsContainer.appendChild(questionClone);
            }
            function updateQuestionNumbers() {
                const questions = questionsContainer.querySelectorAll('.question-card');
                questions.forEach((question, index) => {
                    question.querySelector('.question-number').textContent = index + 1;
                });
            }
        });
    </script>
</body>
</html>