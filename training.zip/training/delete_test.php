<?php 
include 'config.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_id'])) {
    $test_id = (int)$_POST['test_id'];
    
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("DELETE ua FROM user_answers ua 
                              JOIN test_results tr ON ua.test_result_id = tr.id 
                              WHERE tr.test_id = ?");
        $stmt->execute([$test_id]);
        
        $stmt = $pdo->prepare("DELETE FROM test_results WHERE test_id = ?");
        $stmt->execute([$test_id]);
        
        $stmt = $pdo->prepare("DELETE FROM questions WHERE test_id = ?");
        $stmt->execute([$test_id]);
        
        $stmt = $pdo->prepare("DELETE FROM tests WHERE id = ?");
        $stmt->execute([$test_id]);
        
        $pdo->commit();
        
        $_SESSION['message'] = "Тест и все связанные данные успешно удалены";
        $_SESSION['message_type'] = "success";
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['message'] = "Ошибка при удалении теста: " . $e->getMessage();
        $_SESSION['message_type'] = "danger";
        error_log("Ошибка удаления теста: " . $e->getMessage());
    }
    
    redirect('admin.php');
    exit;
}

$_SESSION['message'] = "Неверный запрос";
$_SESSION['message_type'] = "danger";
redirect('admin.php');
?>