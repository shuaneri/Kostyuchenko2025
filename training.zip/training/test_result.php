<?php include 'config.php'; 

if (!isLoggedIn()) {
    redirect('login.php');
}

if (!isset($_GET['id'])) {
    redirect(isAdmin() ? 'admin.php' : 'dashboard.php');
}

$result_id = (int)$_GET['id'];
$query = isAdmin() 
    ? "SELECT tr.*, t.title as test_title, u.username, u.full_name 
       FROM test_results tr 
       JOIN tests t ON tr.test_id = t.id 
       JOIN users u ON tr.user_id = u.id 
       WHERE tr.id = ?"
    : "SELECT tr.*, t.title as test_title 
       FROM test_results tr 
       JOIN tests t ON tr.test_id = t.id 
       WHERE tr.id = ? AND tr.user_id = ?";

$params = isAdmin() ? [$result_id] : [$result_id, $_SESSION['user_id']];
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$result = $stmt->fetch();

if (!$result) {
    $_SESSION['message'] = "Результат теста не найден";
    $_SESSION['message_type'] = "danger";
    redirect(isAdmin() ? 'admin.php' : 'dashboard.php');
}

$questions = $pdo->prepare("
    SELECT q.*, 
           (SELECT a.answer FROM user_answers a WHERE a.test_result_id = ? AND a.question_id = q.id) as user_answer
    FROM questions q 
    WHERE q.test_id = ?
");
$questions->execute([$result_id, $result['test_id']]);
$questions = $questions->fetchAll();

if (!isAdmin()) {
    $_SESSION['test_answers'] = [];
    foreach ($questions as $q) {
        $_SESSION['test_answers'][$q['id']] = $q['user_answer'];
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Результат теста</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .result-header {
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 10px;
        }
        .question-result {
            border-left: 4px solid #dee2e6;
            padding-left: 1rem;
            margin-bottom: 1.5rem;
        }
        .correct {
            border-left-color: #28a745;
        }
        .incorrect {
            border-left-color: #dc3545;
        }
        .progress {
            height: 2rem;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Обучение персонала</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo isAdmin() ? 'admin.php' : 'dashboard.php'; ?>">
                            <?php echo isAdmin() ? 'Админ-панель' : 'Личный кабинет'; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tests.php">Тесты</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link"><?php echo isAdmin() ? 'Администратор' : 'Пользователь'; ?>: <?php echo $_SESSION['username']; ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Выйти</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <div class="result-header text-center">
            <h2>Результат теста: <?php echo htmlspecialchars($result['test_title']); ?></h2>
            <?php if (isAdmin()): ?>
                <p class="lead mb-0">Пользователь: <?php echo htmlspecialchars($result['full_name']); ?> (<?php echo htmlspecialchars($result['username']); ?>)</p>
            <?php endif; ?>
        </div>
        
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h5>Общий результат:</h5>
                        <div class="d-flex align-items-center mb-3">
                            <div class="me-3">
                                <span class="display-4 <?php echo $result['passed'] ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo $result['score']; ?>/<?php echo $result['total_questions']; ?>
                                </span>
                            </div>
                            <div>
                                <span class="badge bg-<?php echo $result['passed'] ? 'success' : 'danger'; ?>">
                                    <?php echo $result['passed'] ? 'Пройден' : 'Не пройден'; ?>
                                </span>
                                <p class="mb-0"><?php echo round($result['score'] / $result['total_questions'] * 100); ?>% правильных ответов</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h5>Прогресс:</h5>
                        <div class="progress mb-2">
                            <div class="progress-bar bg-<?php echo $result['passed'] ? 'success' : 'danger'; ?>" 
                                 role="progressbar" 
                                 style="width: <?php echo round($result['score'] / $result['total_questions'] * 100); ?>%" 
                                 aria-valuenow="<?php echo round($result['score'] / $result['total_questions'] * 100); ?>" 
                                 aria-valuemin="0" 
                                 aria-valuemax="100">
                            </div>
                        </div>
                        <p class="mb-0">Дата прохождения: <?php echo date('d.m.Y H:i', strtotime($result['completed_at'])); ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <h4 class="mb-3">Детализация ответов:</h4>
        
        <?php foreach ($questions as $index => $question): ?>
            <?php 
            $is_correct = $question['user_answer'] == $question['correct_option'];
            $user_answer_text = '';
            if ($question['user_answer'] == 1) $user_answer_text = $question['option1'];
            elseif ($question['user_answer'] == 2) $user_answer_text = $question['option2'];
            elseif ($question['user_answer'] == 3) $user_answer_text = $question['option3'];
            elseif ($question['user_answer'] == 4) $user_answer_text = $question['option4'];
            
            $correct_answer_text = '';
            if ($question['correct_option'] == 1) $correct_answer_text = $question['option1'];
            elseif ($question['correct_option'] == 2) $correct_answer_text = $question['option2'];
            elseif ($question['correct_option'] == 3) $correct_answer_text = $question['option3'];
            elseif ($question['correct_option'] == 4) $correct_answer_text = $question['option4'];
            ?>
            
            <div class="question-result <?php echo $is_correct ? 'correct' : 'incorrect'; ?>">
                <h5>Вопрос <?php echo $index + 1; ?>: <?php echo htmlspecialchars($question['question_text']); ?></h5>
                
                <div class="mb-2">
                    <strong>Ваш ответ:</strong> 
                    <?php if ($question['user_answer']): ?>
                        <span class="<?php echo $is_correct ? 'text-success' : 'text-danger'; ?>">
                            <?php echo htmlspecialchars($user_answer_text); ?>
                        </span>
                    <?php else: ?>
                        <span class="text-danger">Нет ответа</span>
                    <?php endif; ?>
                </div>
                
                <?php if (!$is_correct): ?>
                    <div class="mb-2">
                        <strong>Правильный ответ:</strong> 
                        <span class="text-success"><?php echo htmlspecialchars($correct_answer_text); ?></span>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        
        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
            <a href="<?php echo isAdmin() ? 'admin.php#results-tab' : 'tests.php'; ?>" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Назад
            </a>
            <?php if (!isAdmin()): ?>
                <a href="take_test.php?id=<?php echo $result['test_id']; ?>" class="btn btn-primary">
                    <i class="bi bi-arrow-repeat"></i> Пройти тест снова
                </a>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>