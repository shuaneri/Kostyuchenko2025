<?php include 'config.php'; 

if (!isLoggedIn()) {
    redirect('login.php');
}

if (isAdmin()) {
    redirect('admin.php');
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

$stmt = $pdo->prepare("SELECT tr.*, t.title FROM test_results tr JOIN tests t ON tr.test_id = t.id WHERE tr.user_id = ? ORDER BY tr.completed_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$test_results = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .profile-card {
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        .test-result-card {
            transition: transform 0.3s;
        }
        .test-result-card:hover {
            transform: translateY(-3px);
        }
        .passed {
            border-left: 5px solid #28a745;
        }
        .failed {
            border-left: 5px solid #dc3545;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Обучение персонала</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">Личный кабинет</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tests.php">Доступные тесты</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Выйти</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card profile-card h-100">
                    <div class="card-body text-center">
                        <div class="mb-3">
                            <i class="bi bi-person-circle" style="font-size: 5rem; color: #6e8efb;"></i>
                        </div>
                        <h3><?php echo htmlspecialchars($user['full_name']); ?></h3>
                        <p class="text-muted">@<?php echo htmlspecialchars($user['username']); ?></p>
                        <hr>
                        <p><i class="bi bi-envelope me-2"></i> <?php echo htmlspecialchars($user['email']); ?></p>
                        <p><i class="bi bi-calendar me-2"></i> Зарегистрирован: <?php echo date('d.m.Y', strtotime($user['created_at'])); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Результаты тестов</h4>
                    </div>
                    <div class="card-body">
                        <?php if (empty($test_results)): ?>
                            <div class="alert alert-info">
                                Вы еще не проходили тесты. <a href="tests.php" class="alert-link">Перейти к тестам</a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Тест</th>
                                            <th>Результат</th>
                                            <th>Дата прохождения</th>
                                            <th>Детали</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($test_results as $result): ?>
                                            <tr class="<?php echo $result['passed'] ? 'table-success' : 'table-danger'; ?>">
                                                <td><?php echo htmlspecialchars($result['title']); ?></td>
                                                <td><?php echo $result['score'] . '/' . $result['total_questions']; ?></td>
                                                <td><?php echo date('d.m.Y H:i', strtotime($result['completed_at'])); ?></td>
                                                <td>
                                                    <a href="test_result.php?id=<?php echo $result['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                        Подробнее
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h4 class="mb-0">Доступные тесты</h4>
                    </div>
                    <div class="card-body">
                        <p>Пройдите доступные тесты для проверки своих знаний.</p>
                        <a href="tests.php" class="btn btn-primary">Перейти к тестам</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>