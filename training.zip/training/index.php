<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Система обучения персонала</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            color: white;
            padding: 5rem 0;
            margin-bottom: 3rem;
        }
        .feature-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: #6e8efb;
        }
        .card {
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        footer {
            background-color: #343a40;
            color: white;
            padding: 2rem 0;
            margin-top: 3rem;
        }
    </style>
</head>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Обучение персонала</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
               
                <ul class="navbar-nav">
                <li class="nav-item">
                        <a class="nav-link active" href="index.php">Главная</a>
                    </li>
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo isAdmin() ? 'admin.php' : 'dashboard.php'; ?>">
                                <?php echo isAdmin() ? 'Админ-панель' : 'Личный кабинет'; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Выйти</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Вход</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="register.php">Регистрация</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="display-4 fw-bold">Онлайн-платформа для обучения сотрудников</h1>
            <p class="lead">Повышайте квалификацию, проходите тесты и отслеживайте свои результаты</p>
            <?php if (!isLoggedIn()): ?>
                <a href="register.php" class="btn btn-light btn-lg mt-3">Начать обучение</a>
            <?php else: ?>
                <a href="<?php echo isAdmin() ? 'admin.php' : 'dashboard.php'; ?>" class="btn btn-outline-light btn-lg mt-3">
                    <?php echo isAdmin() ? 'Перейти в админ-панель' : 'Перейти в личный кабинет'; ?>
                </a>
            <?php endif; ?>
        </div>
    </section>
    <div class="container my-5">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="feature-icon">
                            <i class="bi bi-book"></i>
                        </div>
                        <h3>Обучение</h3>
                        <p>Доступ к учебным материалам и тестам для повышения квалификации</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="feature-icon">
                            <i class="bi bi-clipboard-check"></i>
                        </div>
                        <h3>Тестирование</h3>
                        <p>Проверка знаний с помощью интерактивных тестов с автоматической проверкой</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="feature-icon">
                            <i class="bi bi-graph-up"></i>
                        </div>
                        <h3>Отчетность</h3>
                        <p>Отслеживание результатов и прогресса в личном кабинете</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="text-center">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Система обучения персонала. Все права защищены.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>