<?php include 'config.php'; 

if (!isLoggedIn() || isAdmin()) {
    redirect('login.php');
}

if (!isset($_GET['id'])) {
    redirect('tests.php');
}

$test_id = (int)$_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM tests WHERE id = ?");
$stmt->execute([$test_id]);
$test = $stmt->fetch();

if (!$test) {
    $_SESSION['message'] = "Тест не найден";
    $_SESSION['message_type'] = "danger";
    redirect('tests.php');
}

$questions = $pdo->prepare("SELECT * FROM questions WHERE test_id = ? ORDER BY id");
$questions->execute([$test_id]);
$questions = $questions->fetchAll();

if (empty($questions)) {
    $_SESSION['message'] = "В этом тесте нет вопросов";
    $_SESSION['message_type'] = "danger";
    redirect('tests.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $score = 0;
    $total_questions = count($questions);
    
    try {
        $pdo->beginTransaction();
        
        foreach ($questions as $question) {
            $user_answer = isset($_POST['question_' . $question['id']]) ? (int)$_POST['question_' . $question['id']] : 0;
            if ($user_answer == $question['correct_option']) {
                $score++;
            }
        }
        
        $passed = ($score / $total_questions) >= 0.7;
        
    
        $stmt = $pdo->prepare("INSERT INTO test_results (user_id, test_id, score, total_questions, passed) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $_SESSION['user_id'], 
            $test_id, 
            $score, 
            $total_questions, 
            $passed ? 1 : 0
        ]);
        $test_result_id = $pdo->lastInsertId();
    
        foreach ($questions as $question) {
            $user_answer = isset($_POST['question_' . $question['id']]) ? (int)$_POST['question_' . $question['id']] : 0;
            $stmt = $pdo->prepare("INSERT INTO user_answers (test_result_id, question_id, answer) VALUES (?, ?, ?)");
            $stmt->execute([$test_result_id, $question['id'], $user_answer]);
        }
        
        $pdo->commit();
        
        $_SESSION['message'] = $passed 
            ? "Поздравляем! Вы успешно прошли тест." 
            : "Вы не прошли тест. Попробуйте еще раз.";
        $_SESSION['message_type'] = $passed ? "success" : "danger";
        
        redirect('test_result.php?id=' . $test_result_id);
        exit;
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['message'] = "Ошибка при сохранении результатов: " . $e->getMessage();
        $_SESSION['message_type'] = "danger";
        error_log("Ошибка сохранения теста: " . $e->getMessage()); // Логируем ошибку
        redirect('tests.php');
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Прохождение теста</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .question-card {
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            background-color: #f8f9fa;
        }
        .test-header {
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 10px;
        }
        .form-check-input:checked {
            background-color: #6e8efb;
            border-color: #6e8efb;
        }
        .timer {
            font-size: 1.2rem;
            font-weight: bold;
            background-color: #f8f9fa;
            color: #333;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Обучение персонала</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Личный кабинет</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="tests.php">Тесты</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">Пользователь: <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Выйти</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <div class="test-header text-center">
            <h2><?php echo htmlspecialchars($test['title']); ?></h2>
            <p class="lead mb-0"><?php echo htmlspecialchars($test['description']); ?></p>
            <div class="mt-3 timer" id="timer">20:00</div>
        </div>
        
        <form method="POST" id="testForm">
            <?php foreach ($questions as $index => $question): ?>
                <div class="question-card">
                    <h5 class="mb-3">Вопрос <?php echo $index + 1; ?>: <?php echo htmlspecialchars($question['question_text']); ?></h5>
                    
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="question_<?php echo $question['id']; ?>" id="q<?php echo $question['id']; ?>_option1" value="1" required>
                        <label class="form-check-label" for="q<?php echo $question['id']; ?>_option1">
                            <?php echo htmlspecialchars($question['option1']); ?>
                        </label>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="question_<?php echo $question['id']; ?>" id="q<?php echo $question['id']; ?>_option2" value="2">
                        <label class="form-check-label" for="q<?php echo $question['id']; ?>_option2">
                            <?php echo htmlspecialchars($question['option2']); ?>
                        </label>
                    </div>
                    <?php if (!empty($question['option3'])): ?>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="radio" name="question_<?php echo $question['id']; ?>" id="q<?php echo $question['id']; ?>_option3" value="3">
                            <label class="form-check-label" for="q<?php echo $question['id']; ?>_option3">
                                <?php echo htmlspecialchars($question['option3']); ?>
                            </label>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($question['option4'])): ?>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="radio" name="question_<?php echo $question['id']; ?>" id="q<?php echo $question['id']; ?>_option4" value="4">
                            <label class="form-check-label" for="q<?php echo $question['id']; ?>_option4">
                                <?php echo htmlspecialchars($question['option4']); ?>
                            </label>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
            
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary btn-lg">Завершить тест</button>
                <a href="tests.php" class="btn btn-outline-secondary">Отмена</a>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let timeInSeconds = 20 * 60; 
        
        function updateTimer() {
            const minutes = Math.floor(timeInSeconds / 60);
            const seconds = timeInSeconds % 60;
            
            document.getElementById('timer').textContent = 
                `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            
            if (timeInSeconds <= 0) {
                document.getElementById('testForm').submit();
            } else {
                timeInSeconds--;
                setTimeout(updateTimer, 1000);
            }
        }
        
        document.addEventListener('DOMContentLoaded', updateTimer);
        
        window.addEventListener('beforeunload', function(e) {
            const answeredQuestions = document.querySelectorAll('input[type="radio"]:checked').length;
            if (answeredQuestions > 0) {
                e.preventDefault();
                e.returnValue = 'Вы уверены, что хотите покинуть страницу? Ваши ответы могут быть потеряны.';
                return e.returnValue;
            }
        });

        document.getElementById('testForm').addEventListener('submit', function(e) {
            const answeredQuestions = document.querySelectorAll('input[type="radio"]:checked').length;
            if (answeredQuestions === 0) {
                e.preventDefault();
                alert('Пожалуйста, ответьте хотя бы на один вопрос перед отправкой теста.');
            }
        });
    </script>
</body>
</html>