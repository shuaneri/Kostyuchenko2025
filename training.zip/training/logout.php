<?php
include 'config.php';

session_unset();
session_destroy();

$_SESSION['message'] = "Вы успешно вышли из системы";
$_SESSION['message_type'] = "success";

redirect('login.php');
?>